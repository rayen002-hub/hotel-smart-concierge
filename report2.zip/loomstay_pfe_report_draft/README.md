# Rapport PFE LoomStay — Draft LaTeX

Ce dossier contient une première version complète du rapport PFE LoomStay en LaTeX.

## Contenu
- `main.tex` : document principal.
- `chapters/` : chapitres du rapport.
- `tables/` : tableaux réutilisables.
- `diagrams/plantuml/` : codes PlantUML des diagrammes.
- `screenshots/` : dossiers prévus pour les captures.

## À compléter
- Exporter les fichiers PlantUML en images et les insérer dans le rapport si nécessaire.
- Ajouter les captures d'écran réelles.
- Vérifier les informations officielles de Loomens.
- Vérifier la page de garde selon le modèle ISIMM.

## Règles respectées
- 3 releases et 9 sprints uniquement.
- Build/tests comme Definition of Done, pas comme release.
- IA intégrée aux sprints fonctionnels : traduction en Sprint 6, classification en Sprint 7.
- Supabase, Vercel, Render et Hugging Face décrits comme infrastructure de démonstration uniquement.
